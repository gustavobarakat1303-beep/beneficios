
import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { db, useDataSync, subscribe } from '../services/dataService';
import { WhitelistEntry, Voucher, VoucherStatus, Campaign, EligibilityMode, EstablishmentUnit, BenefitType } from '../types';
import toast from 'react-hot-toast';
import { 
  Users, Ticket, Trash2, Database, UploadCloud, Clock, 
  X, Plus, Edit3, Power, Save, Store, MapPin, Image as ImageIcon, FileSpreadsheet, Info, Menu, Camera, LogOut, Home, ChevronLeft,
  ExternalLink, Copy, LayoutGrid, Building2, RefreshCw
} from 'lucide-react';
import * as XLSX from 'xlsx';

const AdminModule = () => {
  useDataSync();
  const [isLogged, setIsLogged] = useState(false);
  const [activeTab, setActiveTab] = useState<'audit' | 'campaigns' | 'units'>('audit');
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [whitelist, setWhitelist] = useState<WhitelistEntry[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [units, setUnits] = useState<EstablishmentUnit[]>([]);

  const [editingCampaign, setEditingCampaign] = useState<Partial<Campaign> | null>(null);
  const [editingUnit, setEditingUnit] = useState<Partial<EstablishmentUnit> | null>(null);
  
  const loadData = useCallback(() => {
    setVouchers(db.vouchers.all());
    setWhitelist(db.whitelist.all());
    setCampaigns(db.campaigns.all());
    setUnits(db.units.all());
  }, []);

  // Re-carrega dados quando houver sincronização em tempo real
  useEffect(() => {
    if (isLogged) {
      return subscribe(() => loadData());
    }
  }, [isLogged, loadData]);

  useEffect(() => {
    if (isLogged) loadData();
  }, [isLogged, loadData]);

  const filteredVouchers = vouchers.filter(v => 
    v.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    v.customerCode?.toUpperCase().includes(searchTerm.toUpperCase()) ||
    v.code?.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice().reverse();

  if (!isLogged) return <AdminLogin onLogin={() => setIsLogged(true)} />;

  const handleSpreadsheetUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        const entries: WhitelistEntry[] = json.map((row: any) => {
          const keys = Object.keys(row);
          const codeKey = keys.find(k => {
            const normalized = k.toLowerCase().replace(/\s/g, '');
            return normalized === 'cpf' || normalized === 'codigo' || normalized === 'code' || normalized === 'subscriber';
          });
          const nameKey = keys.find(k => k.toLowerCase().includes('nome') || k.toLowerCase().includes('name'));
          if (codeKey && nameKey) {
            const rawCode = String(row[codeKey]).trim().toUpperCase();
            const rawName = String(row[nameKey]).trim();
            if (rawCode.length >= 3 && rawName) return { code: rawCode, name: rawName };
          }
          return null;
        }).filter((item): item is WhitelistEntry => item !== null);

        if (entries.length > 0) {
          db.whitelist.addBatch(entries);
          toast.success(`${entries.length} assinantes importados!`);
          loadData();
          e.target.value = '';
        } else toast.error("Nenhum dado válido encontrado.");
      } catch (err) { toast.error("Falha ao processar arquivo"); }
    };
    reader.readAsArrayBuffer(file);
  };

  const saveCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCampaign) return;
    const campaignToSave: Campaign = {
      id: editingCampaign.id || `camp-${Math.random().toString(36).substr(2, 9)}`,
      name: editingCampaign.name || '',
      partner: editingCampaign.partner || '',
      value: Number(editingCampaign.benefit_value) || editingCampaign.value || 0,
      totalLimit: Number(editingCampaign.totalLimit) || 1000,
      monthlyLimit: Number(editingCampaign.monthlyLimit) || 100,
      hardStopDate: editingCampaign.hardStopDate || '2027-12-31T23:59:59',
      active: editingCampaign.active ?? true,
      eligibilityMode: editingCampaign.eligibilityMode || EligibilityMode.WHITELIST,
      requirePreRegisteredPhone: false,
      allowedUnits: editingCampaign.allowedUnits || [],
      limitPerCodePerMonth: Number(editingCampaign.limitPerCodePerMonth) || 1,
      monthlyUsageLimit: Number(editingCampaign.monthlyUsageLimit) || Number(editingCampaign.monthlyLimit) || 100,
      months: editingCampaign.months || [],
      rules_text: editingCampaign.rules_text || '',
      partner_logo_url: editingCampaign.partner_logo_url || '',
      contractor_logo_url: editingCampaign.contractor_logo_url || '',
      benefit_type: editingCampaign.benefit_type || 'fixed_amount',
      benefit_value: Number(editingCampaign.benefit_value) || 0,
      voucherValidityDays: Number(editingCampaign.voucherValidityDays) || 0
    };

    // Garantir que o mês atual existe no estoque se houver limite mensal
    const now = new Date();
    const currentMonthStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}`;
    if (!campaignToSave.months.find(m => m.month === currentMonthStr)) {
      campaignToSave.months.push({
        id: `month-${Math.random().toString(36).substr(2, 9)}`,
        month: currentMonthStr,
        limit: campaignToSave.monthlyLimit,
        issued_count: 0,
        used_count: 0
      });
    } else {
      // Atualizar o limite do mês atual se ele já existir
      const mIdx = campaignToSave.months.findIndex(m => m.month === currentMonthStr);
      campaignToSave.months[mIdx].limit = campaignToSave.monthlyLimit;
    }
    db.campaigns.save(campaignToSave);
    toast.success('Campanha salva!');
    loadData();
    setEditingCampaign(null);
  };

  const saveUnit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUnit) return;
    const unitToSave: EstablishmentUnit = {
      id: editingUnit.id || `unit-${Math.random().toString(36).substr(2, 9)}`,
      name: editingUnit.name || '',
      address: editingUnit.address || '',
      city: editingUnit.city || '',
      active: editingUnit.active ?? true,
      logoUrl: editingUnit.logoUrl || ''
    };
    db.units.save(unitToSave);
    toast.success('Unidade salva!');
    loadData();
    setEditingUnit(null);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'partner' | 'contractor' | 'unit' = 'unit') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const b64 = evt.target?.result as string;
      if (target === 'partner') setEditingCampaign(prev => ({ ...prev, partner_logo_url: b64 }));
      else if (target === 'contractor') setEditingCampaign(prev => ({ ...prev, contractor_logo_url: b64 }));
      else setEditingUnit(prev => ({ ...prev, logoUrl: b64 }));
      toast.success("Logotipo carregado!");
    };
    reader.readAsDataURL(file);
  };

  const NavContent = () => (
    <>
      <div className="font-black text-2xl text-indigo-400 flex items-center gap-2 mb-8 px-2">
        <Database size={24} /> VoucherHub
      </div>
      <div className="space-y-1">
        <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 px-2">Gerenciamento</p>
        <button onClick={() => { setActiveTab('audit'); setIsMobileMenuOpen(false); }} className={`w-full text-left p-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'audit' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}><Clock size={16}/> Auditoria</button>
        <button onClick={() => { setActiveTab('campaigns'); setIsMobileMenuOpen(false); }} className={`w-full text-left p-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'campaigns' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}><Ticket size={16}/> Campanhas</button>
        <button onClick={() => { setActiveTab('units'); setIsMobileMenuOpen(false); }} className={`w-full text-left p-3 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'units' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}><Store size={16}/> Unidades</button>
      </div>
      <div className="mt-auto space-y-4">
        <Link to="/" className="w-full text-left p-3 rounded-xl font-bold text-sm text-slate-400 hover:text-white transition-all flex items-center gap-2">
          <Home size={16}/> Sair para Home
        </Link>
        <button onClick={() => { db.clearAll(); loadData(); }} className="w-full text-left p-2 text-slate-500 hover:text-red-400 font-bold text-xs transition-colors flex items-center gap-2">
          <Trash2 size={14}/> Resetar Sistema
        </button>
      </div>
    </>
  );

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-slate-50 font-sans">
      
      {/* MOBILE HEADER */}
      <header className="md:hidden bg-slate-900 p-4 flex justify-between items-center sticky top-0 z-40 text-white shadow-lg">
        <div className="font-black text-indigo-400 flex items-center gap-2">
          <Database size={20} /> VoucherHub
        </div>
        <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 bg-white/10 rounded-lg">
          <Menu size={20} />
        </button>
      </header>

      {/* MOBILE DRAWER OVERLAY */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 md:hidden" 
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* SIDEBAR (Desktop e Mobile Drawer) */}
      <aside className={`
        fixed md:sticky top-0 left-0 h-screen w-64 bg-slate-900 border-r border-slate-800 p-8 flex flex-col gap-8 no-print text-white shrink-0 z-50 transition-transform duration-300
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <button onClick={() => setIsMobileMenuOpen(false)} className="md:hidden absolute top-4 right-4 text-slate-400">
          <X size={24} />
        </button>
        <NavContent />
        
        <div className="mt-auto pt-4 border-t border-slate-800">
          <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            Cloud Sync Ativo
          </div>
          <button 
            onClick={() => window.location.reload()} 
            className="w-full py-2 px-3 bg-white/5 hover:bg-white/10 rounded-lg text-[10px] font-bold uppercase tracking-widest text-slate-400 flex items-center justify-center gap-2 transition-all mb-2"
          >
            <RefreshCw size={12} />
            Forçar Atualização
          </button>
          <button 
            onClick={() => {
              if(confirm('Isso limpará os dados temporários do navegador e recarregará tudo da nuvem. Continuar?')) {
                localStorage.clear();
                window.location.reload();
              }
            }} 
            className="w-full py-2 px-3 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-[10px] font-bold uppercase tracking-widest text-red-400 flex items-center justify-center gap-2 transition-all"
          >
            <Trash2 size={12} />
            Limpar Dados Locais
          </button>
        </div>
      </aside>

      <main className="flex-1 p-4 md:p-12 overflow-y-auto">
        {activeTab === 'audit' && (
          <AuditTab 
            vouchers={filteredVouchers} 
            whitelist={whitelist} 
            searchTerm={searchTerm} 
            setSearchTerm={setSearchTerm} 
            onFileUpload={handleSpreadsheetUpload} 
          />
        )}
        
        {activeTab === 'campaigns' && (
          <CampaignManager 
            campaigns={campaigns} 
            units={units} 
            onEdit={setEditingCampaign} 
            onNew={() => setEditingCampaign({ allowedUnits: [], active: true, benefit_type: 'fixed_amount', benefit_value: 0 })} 
            onDelete={(id: string) => { if(confirm('Excluir?')) { db.campaigns.delete(id); loadData(); } }}
          />
        )}
        
        {activeTab === 'units' && (
          <UnitManager 
            units={units} 
            onEdit={setEditingUnit} 
            onNew={() => setEditingUnit({ active: true, logoUrl: '' })} 
            onDelete={(id: string) => { if(confirm('Remover?')) { db.units.delete(id); loadData(); } }}
          />
        )}

        {/* Modal Unidade */}
        {editingUnit && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-6 bg-emerald-600 text-white flex justify-between items-center">
                <h3 className="text-xl font-black">{editingUnit.id ? 'Configurar Unidade' : 'Novo PDV'}</h3>
                <button onClick={() => setEditingUnit(null)} className="p-2 hover:bg-black/10 rounded-full transition-colors"><X size={20}/></button>
              </div>
              <form onSubmit={saveUnit} className="p-8 space-y-6">
                <div className="flex flex-col items-center">
                  <div className="relative group">
                    <div className="w-24 h-24 bg-slate-100 rounded-[1.5rem] border-2 border-dashed border-slate-300 flex items-center justify-center overflow-hidden transition-all">
                      {editingUnit.logoUrl ? (
                        <img src={editingUnit.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                      ) : (
                        <ImageIcon size={32} className="text-slate-300" />
                      )}
                    </div>
                    <label className="absolute inset-0 cursor-pointer opacity-0 z-10">
                      <input type="file" accept="image/*" onChange={(e) => handleLogoUpload(e, 'unit')} className="hidden" />
                    </label>
                  </div>
                </div>
                <div className="space-y-4">
                  <input required value={editingUnit.name || ''} onChange={e => setEditingUnit({...editingUnit, name: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border-none ring-1 ring-slate-200 outline-none font-bold" placeholder="Nome Unidade" />
                  <input required value={editingUnit.city || ''} onChange={e => setEditingUnit({...editingUnit, city: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl border-none ring-1 ring-slate-200 outline-none font-bold" placeholder="Cidade" />
                </div>
                <button type="submit" className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black shadow-xl hover:bg-emerald-700">Salvar Unidade</button>
              </form>
            </div>
          </div>
        )}

        {/* Modal Campanha */}
        {editingCampaign && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 my-auto">
              <div className="p-6 bg-indigo-600 text-white flex justify-between items-center">
                <h3 className="text-xl font-black">{editingCampaign.id ? 'Editar Campanha' : 'Nova Campanha'}</h3>
                <button onClick={() => setEditingCampaign(null)} className="p-2 hover:bg-white/10 rounded-full"><X size={20}/></button>
              </div>
              <form onSubmit={saveCampaign} className="p-6 space-y-6 max-h-[85vh] overflow-y-auto custom-scrollbar">
                
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
                  <div className="flex flex-col items-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Logo do Parceiro</p>
                    <div className="relative group">
                      <div className="w-20 h-20 bg-white rounded-2xl border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden transition-all group-hover:border-indigo-400 group-hover:bg-indigo-50/30">
                        {editingCampaign.partner_logo_url ? (
                          <img src={editingCampaign.partner_logo_url} alt="Logo Parceiro" className="w-full h-full object-cover" />
                        ) : (
                          <ImageIcon size={24} className="text-slate-300 group-hover:text-indigo-400" />
                        )}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Camera className="text-white" size={20} />
                        </div>
                      </div>
                      <label className="absolute inset-0 cursor-pointer opacity-0 z-10">
                        <input type="file" accept="image/*" onChange={(e) => handleLogoUpload(e, 'partner')} className="hidden" />
                      </label>
                    </div>
                  </div>

                  <div className="flex flex-col items-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Logo do Contratante</p>
                    <div className="relative group">
                      <div className="w-20 h-20 bg-white rounded-2xl border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden transition-all group-hover:border-indigo-400 group-hover:bg-indigo-50/30">
                        {editingCampaign.contractor_logo_url ? (
                          <img src={editingCampaign.contractor_logo_url} alt="Logo Contratante" className="w-full h-full object-cover" />
                        ) : (
                          <ImageIcon size={24} className="text-slate-300 group-hover:text-indigo-400" />
                        )}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Camera className="text-white" size={20} />
                        </div>
                      </div>
                      <label className="absolute inset-0 cursor-pointer opacity-0 z-10">
                        <input type="file" accept="image/*" onChange={(e) => handleLogoUpload(e, 'contractor')} className="hidden" />
                      </label>
                    </div>
                  </div>
                  <p className="col-span-2 text-[9px] text-slate-400 mt-1 font-medium text-center">Recomendado: PNG ou JPG quadrado</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Nome da Campanha</p>
                    <input required value={editingCampaign.name || ''} onChange={e => setEditingCampaign({...editingCampaign, name: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="Ex: Assinante Premium" />
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Marca/Parceiro</p>
                    <input required value={editingCampaign.partner || ''} onChange={e => setEditingCampaign({...editingCampaign, partner: e.target.value.toUpperCase()})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="Ex: UOL" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Tipo de Benefício</p>
                    <select value={editingCampaign.benefit_type || 'fixed_amount'} onChange={e => setEditingCampaign({...editingCampaign, benefit_type: e.target.value as BenefitType})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 font-bold outline-none focus:ring-2 focus:ring-indigo-500">
                      <option value="fixed_amount">Desconto Valor Fixo (R$)</option>
                      <option value="percent">Desconto Percentual (%)</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Valor do Benefício</p>
                    <input required type="number" step="0.01" value={editingCampaign.benefit_value || ''} onChange={e => setEditingCampaign({...editingCampaign, benefit_value: Number(e.target.value)})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="0.00" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Limite Mensal (Emissão)</p>
                    <input required type="number" value={editingCampaign.monthlyLimit || ''} onChange={e => setEditingCampaign({...editingCampaign, monthlyLimit: Number(e.target.value)})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="Ex: 100" />
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Limite Mensal (Uso/Validação)</p>
                    <input required type="number" value={editingCampaign.monthlyUsageLimit || ''} onChange={e => setEditingCampaign({...editingCampaign, monthlyUsageLimit: Number(e.target.value)})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="Ex: 100" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Limite por Código/Mês</p>
                  <input required type="number" value={editingCampaign.limitPerCodePerMonth || ''} onChange={e => setEditingCampaign({...editingCampaign, limitPerCodePerMonth: Number(e.target.value)})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="Ex: 1" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Validade da Campanha (Data Limite)</p>
                    <input type="datetime-local" value={editingCampaign.hardStopDate ? editingCampaign.hardStopDate.slice(0, 16) : '2027-12-31T23:59'} onChange={e => setEditingCampaign({...editingCampaign, hardStopDate: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" />
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Validade do Voucher (Dias)</p>
                    <input type="number" value={editingCampaign.voucherValidityDays || ''} onChange={e => setEditingCampaign({...editingCampaign, voucherValidityDays: Number(e.target.value)})} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500" placeholder="Ex: 30" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Regras e Instruções (Opcional)</p>
                  <textarea value={editingCampaign.rules_text || ''} onChange={e => setEditingCampaign({...editingCampaign, rules_text: e.target.value})} rows={3} className="w-full p-4 bg-slate-50 rounded-2xl ring-1 ring-slate-200 outline-none resize-none text-sm focus:ring-2 focus:ring-indigo-500" placeholder="Regras de uso que aparecerão para o cliente..." />
                </div>
                
                <div className="space-y-2">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Lojas Autorizadas</p>
                  <div className="flex flex-wrap gap-2">
                    {units.map(u => (
                      <button key={u.id} type="button" onClick={() => {
                        const current = editingCampaign.allowedUnits || [];
                        const next = current.includes(u.id) ? current.filter(id => id !== u.id) : [...current, u.id];
                        setEditingCampaign({...editingCampaign, allowedUnits: next});
                      }} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all border ${editingCampaign.allowedUnits?.includes(u.id) ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-white text-slate-400 border-slate-200 hover:border-indigo-300'}`}>
                        {u.name}
                      </button>
                    ))}
                  </div>
                </div>

                <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-xl hover:bg-indigo-700 transition-all active:scale-95">Salvar Configurações</button>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

const AuditTab = ({ vouchers, whitelist, searchTerm, setSearchTerm, onFileUpload }: any) => {
  const appBaseUrl = window.location.href.split('#')[0];
  const links = [
    { name: 'Vitrine (Cliente)', url: `${appBaseUrl}#/cliente`, icon: <LayoutGrid size={16}/>, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { name: 'PDV (Operação)', url: `${appBaseUrl}#/operacao`, icon: <Store size={16}/>, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { name: 'Painel Contratante', url: `${appBaseUrl}#/contratante`, icon: <Building2 size={16}/>, color: 'text-sky-600', bg: 'bg-sky-50' },
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Link copiado!");
  };

  return (
  <div className="animate-in fade-in duration-500">
    <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">Monitoramento</h1>
      <div className="flex flex-wrap gap-2">
        {links.map(link => (
          <div key={link.name} className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl p-1.5 pr-3 shadow-sm">
            <div className={`w-8 h-8 ${link.bg} ${link.color} rounded-lg flex items-center justify-center`}>
              {link.icon}
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{link.name}</span>
              <div className="flex items-center gap-2">
                <button onClick={() => copyToClipboard(link.url)} className="text-slate-400 hover:text-indigo-600 transition-colors"><Copy size={10}/></button>
                <a href={link.url} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-indigo-600 transition-colors"><ExternalLink size={10}/></a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </header>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-12">
      <StatCard label="Assinantes" value={whitelist.length} icon={<Users />} color="indigo" />
      <StatCard label="Emitidos" value={vouchers.length} icon={<Ticket />} color="emerald" />
      <StatCard label="Resgates" value={vouchers.filter((v:any) => v.status === VoucherStatus.USED).length} icon={<Clock />} color="amber" />
    </div>
    <div className="grid grid-cols-1 xl:grid-cols-5 gap-8">
      <div className="xl:col-span-2 bg-white p-6 md:p-8 rounded-[2rem] border border-slate-200">
        <h3 className="text-lg font-black mb-6 flex items-center gap-2 text-slate-900"><FileSpreadsheet className="text-indigo-600" size={20}/> Whitelist</h3>
        <label className="group flex flex-col items-center justify-center w-full h-40 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 cursor-pointer hover:border-indigo-400 transition-all text-center p-4">
          <UploadCloud className="w-8 h-8 text-slate-300 group-hover:text-indigo-500 mb-2" />
          <p className="text-[10px] font-black text-slate-500 mb-1">Upload Planilha (XLSX)</p>
          <input type="file" className="hidden" accept=".xlsx, .xls" onChange={onFileUpload} />
        </label>
      </div>
      <div className="xl:col-span-3 bg-white p-6 md:p-8 rounded-[2rem] border border-slate-200">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <h3 className="text-lg font-black text-slate-900">Histórico Recente</h3>
          <input type="text" placeholder="Filtrar..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="px-4 py-2 bg-slate-100 rounded-full text-xs font-bold outline-none w-full md:w-56" />
        </div>
        <div className="space-y-2 overflow-y-auto max-h-[400px] custom-scrollbar pr-1">
          {vouchers.map((v:any) => (
            <div key={v.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
              <div className="truncate pr-4">
                <p className="font-black text-slate-900 truncate">{v.name}</p>
                <p className="text-[9px] text-slate-400 font-bold">{v.customerCode} • {v.code}</p>
              </div>
              <span className={`px-2 py-1 rounded-lg text-[8px] font-black uppercase shrink-0 ${v.status === VoucherStatus.USED ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                {v.status === VoucherStatus.USED ? 'OK' : 'PEND'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
  );
};

const CampaignManager = ({ campaigns, onEdit, onNew, onDelete }: any) => (
  <div className="animate-in fade-in duration-500">
    <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-10">
      <div><h1 className="text-2xl md:text-3xl font-black text-slate-900">Campanhas</h1><p className="text-slate-500 text-sm">Gestão de benefícios.</p></div>
      <button onClick={onNew} className="w-full md:w-auto bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black flex items-center justify-center gap-2"><Plus size={18}/> Nova</button>
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
      {campaigns.map((c:any) => (
        <div key={c.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center overflow-hidden border">
                {c.partner_logo_url ? <img src={c.partner_logo_url} className="w-full h-full object-cover" /> : <Ticket size={20} className="text-slate-300" />}
              </div>
              <h3 className="text-sm font-black text-slate-900">{c.partner}</h3>
            </div>
            <button className={`p-1.5 rounded-lg ${c.active ? 'bg-emerald-50 text-emerald-500' : 'bg-slate-100 text-slate-300'}`}><Power size={16}/></button>
          </div>
          <p className="text-lg font-black text-slate-900 mb-1">{c.benefit_type === 'percent' ? `${c.benefit_value}%` : `R$ ${c.benefit_value?.toFixed(2)}`}</p>
          <div className="space-y-1 mb-6">
            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-1">
              <Clock size={10}/> Data Limite: {new Date(c.hardStopDate).toLocaleDateString('pt-BR')}
            </p>
            {c.voucherValidityDays ? (
              <p className="text-[9px] text-indigo-500 font-bold uppercase tracking-widest flex items-center gap-1">
                <Ticket size={10}/> Validade Voucher: {c.voucherValidityDays} dias
              </p>
            ) : null}
          </div>
          <div className="flex gap-2">
            <button onClick={() => onEdit(c)} className="flex-1 py-2.5 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest">Configurar</button>
            <button onClick={() => onDelete(c.id)} className="p-2.5 bg-red-50 text-red-400 rounded-xl hover:bg-red-500 hover:text-white transition-all"><Trash2 size={16}/></button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const UnitManager = ({ units, onEdit, onNew, onDelete }: any) => (
  <div className="animate-in fade-in duration-500">
    <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-10">
      <div><h1 className="text-2xl md:text-3xl font-black text-slate-900">Unidades</h1><p className="text-slate-500 text-sm">Pontos de venda.</p></div>
      <button onClick={onNew} className="w-full md:w-auto bg-emerald-600 text-white px-6 py-3 rounded-2xl font-black flex items-center justify-center gap-2"><Plus size={18}/> Nova</button>
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {units.map((u:any) => (
        <div key={u.id} className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center overflow-hidden mb-4 border">
             {u.logoUrl ? <img src={u.logoUrl} className="w-full h-full object-cover" /> : <Store size={20} className="text-slate-300" />}
          </div>
          <h3 className="font-black text-slate-900 mb-1">{u.name}</h3>
          <p className="text-[10px] text-slate-500 flex items-center gap-1 mb-4 font-bold uppercase"><MapPin size={10}/> {u.city}</p>
          <div className="flex gap-2">
            <button onClick={() => onEdit(u)} className="flex-1 py-2.5 bg-slate-100 rounded-xl text-[10px] font-black uppercase tracking-widest">Configurar</button>
            <button onClick={() => onDelete(u.id)} className="p-2.5 text-red-400 bg-red-50 rounded-xl"><Trash2 size={16}/></button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const StatCard = ({ label, value, icon, color }: any) => {
  const colors: any = { indigo: 'text-indigo-600 bg-indigo-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50' };
  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colors[color]}`}>{React.cloneElement(icon, { size: 24 })}</div>
      <div><p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{label}</p><p className="text-xl font-black text-slate-900">{value}</p></div>
    </div>
  );
};

// Fix: Added ChevronLeft to imports above to resolve "Cannot find name 'ChevronLeft'" error in this component.
const AdminLogin = ({ onLogin }: any) => {
  const [user, setUser] = useState('');
  const handle = () => { if (user === 'admin') onLogin(); else toast.error('Acesso negado.'); };
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 p-6 relative">
      <Link to="/" className="absolute top-8 left-8 text-slate-400 hover:text-white transition-colors">
        <ChevronLeft size={24} />
      </Link>
      <div className="w-full max-sm bg-white p-10 rounded-[2.5rem] shadow-2xl text-center">
        <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6"><Database className="text-white" size={28}/></div>
        <h2 className="text-xl font-black mb-6 text-slate-900">Admin Login</h2>
        <input value={user} onChange={e => setUser(e.target.value)} onKeyPress={e => e.key === 'Enter' && handle()} type="password" placeholder="Código de Acesso" className="w-full p-4 bg-slate-100 rounded-xl mb-4 text-center font-bold outline-none ring-1 ring-slate-200 focus:ring-2 focus:ring-indigo-500" />
        <button onClick={handle} className="w-full py-4 bg-indigo-600 text-white rounded-xl font-black shadow-lg mb-8">Entrar</button>
        
        <div className="pt-6 border-t border-slate-100 space-y-3">
          <button 
            onClick={() => window.location.reload()} 
            className="w-full py-3 bg-slate-50 text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-all flex items-center justify-center gap-2"
          >
            <RefreshCw size={14} /> Atualizar Página
          </button>
          <button 
            onClick={() => {
              if(confirm('Isso limpará os dados temporários e recarregará tudo da nuvem. Continuar?')) {
                localStorage.clear();
                window.location.reload();
              }
            }} 
            className="w-full py-3 bg-red-50 text-red-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-100 transition-all flex items-center justify-center gap-2"
          >
            <Trash2 size={14} /> Limpar Dados Locais
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminModule;