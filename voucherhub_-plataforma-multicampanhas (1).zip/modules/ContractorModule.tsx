
import React, { useState } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import ContractorDashboard from '../pages/ContractorDashboard';
import { User } from '../types';
import { Building2, ChevronLeft, Lock, ArrowRight } from 'lucide-react';
import toast from 'react-hot-toast';

const ContractorModule: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);

  if (!user) {
    return <ContractorLogin onLogin={setUser} />;
  }

  return (
    <Routes>
      <Route path="/" element={<ContractorDashboard user={user} />} />
    </Routes>
  );
};

const ContractorLogin: React.FC<{ onLogin: (user: User) => void }> = ({ onLogin }) => {
  const [partnerName, setPartnerName] = useState('');
  const [accessCode, setAccessCode] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulação de login por parceiro
    // No mundo real, isso viria de um banco de dados de usuários contratantes
    if (partnerName.toUpperCase() === 'UOL' && accessCode === 'uol2026') {
      onLogin({
        id: 'contractor-uol',
        username: 'uol_admin',
        role: 'contractor',
        partner: 'UOL'
      });
      toast.success('Acesso autorizado para UOL');
    } else if (partnerName.toUpperCase() === 'VOUCHERHUB' && accessCode === 'admin') {
       onLogin({
        id: 'contractor-vh',
        username: 'vh_admin',
        role: 'contractor',
        partner: 'VOUCHERHUB'
      });
      toast.success('Acesso autorizado para VoucherHub');
    } else {
      toast.error('Parceiro ou Código de Acesso inválidos.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-80 h-80 bg-indigo-600/20 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-80 h-80 bg-violet-600/20 rounded-full blur-[120px]"></div>

      <Link to="/" className="absolute top-8 left-8 text-slate-400 hover:text-white transition-all flex items-center gap-2 font-bold text-sm">
        <ChevronLeft size={20} /> Voltar para Home
      </Link>

      <div className="w-full max-w-md bg-white rounded-[3rem] shadow-2xl p-10 md:p-12 relative z-10">
        <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-8 shadow-xl shadow-indigo-200">
          <Building2 className="text-white" size={32} />
        </div>

        <div className="mb-10">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-2">Área do Contratante</h2>
          <p className="text-slate-500 font-medium">Acesse o painel de gestão da sua campanha.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome do Parceiro</label>
            <input 
              type="text" 
              placeholder="Ex: UOL" 
              value={partnerName}
              onChange={e => setPartnerName(e.target.value)}
              className="w-full p-4 bg-slate-50 rounded-2xl border-none ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500 transition-all uppercase"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Código de Acesso</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
              <input 
                type="password" 
                placeholder="••••••••" 
                value={accessCode}
                onChange={e => setAccessCode(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-slate-50 rounded-2xl border-none ring-1 ring-slate-200 outline-none font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                required
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black shadow-xl hover:bg-slate-800 transition-all active:scale-95 flex items-center justify-center gap-2 group"
          >
            Acessar Painel <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        <div className="mt-10 pt-8 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400 font-medium">
            Problemas com o acesso? <br />
            <span className="text-indigo-600 font-bold cursor-pointer hover:underline">Contate o suporte VoucherHub</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ContractorModule;
