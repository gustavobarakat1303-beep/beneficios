
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { db, useDataSync } from '../services/dataService';
import { Voucher, VoucherStatus, EstablishmentUnit } from '../types';
import toast from 'react-hot-toast';
import { Search, CheckCircle, XCircle, LogOut, Ticket, ArrowRight, ShieldCheck, Store, Info, Loader2, ChevronLeft, Home } from 'lucide-react';

const OperationModule = () => {
  useDataSync();
  const [unitId, setUnitId] = useState<string | null>(null);
  const currentUnit = unitId ? db.units.getById(unitId) : null;

  if (!unitId || !currentUnit) return <OpLogin onLogin={setUnitId} />;

  return (
    <div className="max-w-md mx-auto min-h-screen bg-slate-950 text-white p-6 flex flex-col">
      <div className="flex justify-between items-center mb-8 pt-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center overflow-hidden border border-white/10 shadow-lg">
             {currentUnit.logoUrl ? <img src={currentUnit.logoUrl} className="w-full h-full object-cover" alt={currentUnit.name} /> : <ShieldCheck className="text-indigo-600" size={24}/>}
          </div>
          <div>
            <h2 className="text-lg font-black leading-none mb-1">{currentUnit.name}</h2>
            <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Ponto de Venda Ativo</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/" className="p-2 bg-white/5 rounded-full text-slate-500 hover:text-white transition-all"><Home size={18} /></Link>
          <button onClick={() => setUnitId(null)} className="p-2 bg-white/5 rounded-full text-slate-500 hover:text-white transition-all"><LogOut size={18} /></button>
        </div>
      </div>
      
      <Validator unit={currentUnit} />
      
      <div className="mt-auto py-8 text-center">
        <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em]">VoucherHub Enterprise</p>
      </div>
    </div>
  );
};

const OpLogin = ({ onLogin }: any) => {
  const [val, setVal] = useState('');
  const units = db.units.all();

  const handle = () => {
    const unit = units.find(u => u.id === val || u.name.toLowerCase().includes(val.toLowerCase()));
    if (unit) onLogin(unit.id);
    else toast.error('Unidade não encontrada na rede.');
  };

  return (
    <div className="max-w-md mx-auto min-h-screen flex items-center justify-center p-8 bg-slate-950">
      <div className="w-full bg-white p-12 rounded-[3.5rem] shadow-2xl relative">
        <Link to="/" className="absolute top-8 left-8 text-slate-300 hover:text-indigo-600 transition-colors">
          <ChevronLeft size={24} />
        </Link>
        <div className="w-16 h-16 bg-slate-900 rounded-[1.5rem] flex items-center justify-center mb-8 mx-auto shadow-xl shadow-slate-200">
          <Store className="text-white w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 mb-2 text-center tracking-tight">Checkout</h2>
        <p className="text-center text-slate-400 text-sm mb-10 font-medium italic">Autentique sua unidade para validar benefícios.</p>
        
        <div className="space-y-4">
          <input value={val} onChange={e => setVal(e.target.value)} onKeyPress={e => e.key === 'Enter' && handle()} placeholder="Digite o ID da Unidade" className="w-full p-5 bg-slate-100 rounded-2xl text-slate-900 text-center font-black outline-none border-2 border-transparent focus:border-indigo-500 transition-all" />
          <button onClick={handle} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-xl hover:bg-indigo-700 transition-all active:scale-95">Acessar PDV</button>
        </div>
      </div>
    </div>
  );
};

const Validator = ({ unit }: { unit: EstablishmentUnit }) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const validate = async () => {
    setResult(null);
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return toast.error('Informe o código do voucher.');
    
    setLoading(true);
    try {
      const voucher = await db.vouchers.getByCode(cleanCode);
      if (!voucher) return toast.error('Voucher inexistente.');
      
      if (voucher.status === VoucherStatus.USED) {
        setResult({ status: 'error', msg: `Utilizado em ${new Date(voucher.usedAt!).toLocaleString()} na loja ${db.units.getById(voucher.usedStore || '')?.name || 'Não informada'}.`, holder: voucher.name });
        return;
      }
      
      const campaign = db.campaigns.getById(voucher.campaignId);
      if (!campaign || !campaign.active) return setResult({ status: 'error', msg: 'A campanha deste voucher está pausada ou expirada.' });
      
      if (!campaign.allowedUnits.includes(unit.id)) {
        return setResult({ status: 'error', msg: `Voucher não autorizado nesta unidade.` });
      }

      setResult({ status: 'success', voucher, campaign });
    } finally {
      setLoading(false);
    }
  };

  const confirm = async () => {
    setLoading(true);
    try {
      await db.vouchers.updateStatus(result.voucher.code, VoucherStatus.USED, unit.id);
      toast.success('Check-out realizado com sucesso!');
      setResult(null);
      setCode('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 shadow-2xl">
        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3 block text-center">Código do Voucher</label>
        <input value={code} onChange={e => setCode(e.target.value)} onKeyPress={e => e.key === 'Enter' && validate()} className="w-full bg-slate-950 border-2 border-white/10 p-5 rounded-2xl text-indigo-400 font-mono font-black text-center text-3xl uppercase mb-4 outline-none focus:border-indigo-500 transition-all" placeholder="XXXXXX" />
        <button onClick={validate} disabled={loading} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all">
          {loading ? <Loader2 className="animate-spin" /> : 'Validar Código'}
        </button>
      </div>

      {result && (
        <div className={`p-6 rounded-[2.5rem] border-2 animate-in slide-in-from-bottom-6 duration-300 ${result.status === 'success' ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
          <div className="flex flex-col items-center text-center">
            {result.status === 'success' ? (
              <>
                <CheckCircle className="text-emerald-500 mb-4" size={48} />
                <h3 className="text-xl font-black text-white mb-1">Aprovado</h3>
                <div className="w-full bg-white/5 p-4 rounded-xl border border-white/10 text-left mb-6">
                  <span className="text-[9px] font-black text-slate-500 uppercase block mb-1">Portador</span>
                  <span className="text-white font-black text-lg">{result.voucher.name}</span>
                </div>
                <button onClick={confirm} disabled={loading} className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black text-lg flex items-center justify-center gap-3">
                  {loading ? <Loader2 className="animate-spin" /> : 'Confirmar Resgate'}
                </button>
              </>
            ) : (
              <>
                <XCircle className="text-red-500 mb-4" size={48} />
                <h3 className="text-xl font-black text-white mb-2 uppercase">Negado</h3>
                <p className="text-xs text-slate-400 mb-6">{result.msg}</p>
                <button onClick={() => setResult(null)} className="text-[10px] font-black text-slate-500 uppercase tracking-widest border-2 border-white/5 px-8 py-3 rounded-full">Tentar Outro</button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default OperationModule;