
import React, { useState, useMemo, useEffect } from 'react';
import { db, useDataSync, subscribe } from '../services/dataService';
import { Campaign, Voucher, VoucherStatus, WhitelistEntry, User } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie
} from 'recharts';
import { 
  Users, Ticket, Clock, FileSpreadsheet, UploadCloud, 
  TrendingUp, CheckCircle, AlertCircle, Search, Download,
  ExternalLink, Copy, Store, LayoutGrid
} from 'lucide-react';
import * as XLSX from 'xlsx';
import toast from 'react-hot-toast';

interface ContractorDashboardProps {
  user: User;
}

const ContractorDashboard: React.FC<ContractorDashboardProps> = ({ user }) => {
  useDataSync();
  const [searchTerm, setSearchTerm] = useState('');
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [whitelist, setWhitelist] = useState<WhitelistEntry[]>([]);
  const [selectedCampaignId, setSelectedCampaignId] = useState<string>('all');

  const loadData = () => {
    const allCampaigns = db.campaigns.all().filter(c => c.partner === user.partner);
    const allVouchers = db.vouchers.all().filter(v => {
      const camp = db.campaigns.getById(v.campaignId);
      return camp?.partner === user.partner;
    });
    const allWhitelist = db.whitelist.all().filter(w => {
      if (!w.campaignId) return false;
      const camp = db.campaigns.getById(w.campaignId);
      return camp?.partner === user.partner;
    });

    setCampaigns(allCampaigns);
    setVouchers(allVouchers);
    setWhitelist(allWhitelist);
  };

  useEffect(() => {
    return subscribe(() => loadData());
  }, [user.partner]);

  useEffect(() => {
    loadData();
  }, [user.partner]);

  const filteredCampaigns = useMemo(() => {
    if (selectedCampaignId === 'all') return campaigns;
    return campaigns.filter(c => c.id === selectedCampaignId);
  }, [campaigns, selectedCampaignId]);

  const filteredVouchers = useMemo(() => {
    let filtered = vouchers;
    if (selectedCampaignId !== 'all') {
      filtered = filtered.filter(v => v.campaignId === selectedCampaignId);
    }
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(v => 
        v.name?.toLowerCase().includes(term) || 
        v.customerCode?.toUpperCase().includes(term.toUpperCase()) ||
        v.code?.toLowerCase().includes(term)
      );
    }
    return filtered;
  }, [vouchers, selectedCampaignId, searchTerm]);

  const stats = useMemo(() => {
    const totalIssued = filteredVouchers.length;
    const totalUsed = filteredVouchers.filter(v => v.status === VoucherStatus.USED).length;
    const totalPending = totalIssued - totalUsed;
    
    const chartData = [
      { name: 'Emitidos', value: totalIssued, color: '#6366f1' },
      { name: 'Utilizados', value: totalUsed, color: '#10b981' },
      { name: 'Pendentes', value: totalPending, color: '#f59e0b' }
    ];

    return { totalIssued, totalUsed, totalPending, chartData };
  }, [filteredVouchers]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (selectedCampaignId === 'all') {
      toast.error("Selecione uma campanha específica para subir a lista.");
      return;
    }

    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        
        const entries = json.map((row: any): WhitelistEntry | null => {
          const keys = Object.keys(row);
          const codeKey = keys.find(k => {
            const normalized = k.toLowerCase().replace(/\s/g, '');
            return normalized === 'cpf' || normalized === 'codigo' || normalized === 'code' || normalized === 'subscriber';
          });
          const nameKey = keys.find(k => k.toLowerCase().includes('nome') || k.toLowerCase().includes('name'));
          
          if (codeKey && nameKey) {
            const rawCode = String(row[codeKey]).trim().toUpperCase();
            const rawName = String(row[nameKey]).trim();
            if (rawCode.length >= 3 && rawName) {
              return { code: rawCode, name: rawName, campaignId: selectedCampaignId };
            }
          }
          return null;
        }).filter((item): item is WhitelistEntry => item !== null);

        if (entries.length > 0) {
          db.whitelist.addBatch(entries);
          toast.success(`${entries.length} assinantes importados para a campanha!`);
          loadData();
          e.target.value = '';
        } else {
          toast.error("Nenhum dado válido encontrado (CPF e Nome são obrigatórios).");
        }
      } catch (err) {
        toast.error("Falha ao processar arquivo Excel.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const exportReport = () => {
    const headers = ['Código', 'Nome', 'Assinante', 'Status', 'Emitido em', 'Utilizado em'];
    const rows = filteredVouchers.map(v => [
      v.code,
      v.name,
      v.customerCode,
      v.status === VoucherStatus.USED ? 'Utilizado' : 'Pendente',
      new Date(v.issuedAt).toLocaleString('pt-BR'),
      v.usedAt ? new Date(v.usedAt).toLocaleString('pt-BR') : '-'
    ]);

    const csvContent = [headers, ...rows].map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `relatorio_vouchers_${user.partner}_${new Date().toISOString().split('T')[0]}.csv`);
    link.click();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Link copiado!");
  };

  const appBaseUrl = window.location.href.split('#')[0];
  const vitrineUrl = `${appBaseUrl}#/cliente`;
  const pdvUrl = `${appBaseUrl}#/operacao`;

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Painel do Contratante</h1>
            <p className="text-slate-500 font-medium">Bem-vindo, <span className="text-indigo-600 font-bold">{user.partner}</span></p>
          </div>
          
          <div className="flex items-center gap-3 bg-white p-2 rounded-2xl shadow-sm border border-slate-200">
            <span className="text-xs font-bold text-slate-400 uppercase ml-2">Campanha:</span>
            <select 
              value={selectedCampaignId} 
              onChange={(e) => setSelectedCampaignId(e.target.value)}
              className="bg-slate-50 border-none outline-none text-sm font-bold text-slate-700 px-3 py-1 rounded-xl cursor-pointer"
            >
              <option value="all">Todas as Campanhas</option>
              {campaigns.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard 
            label="Vouchers Emitidos" 
            value={stats.totalIssued} 
            icon={<Ticket className="text-indigo-600" />} 
            trend="+12% este mês"
          />
          <StatCard 
            label="Vouchers Utilizados" 
            value={stats.totalUsed} 
            icon={<CheckCircle className="text-emerald-600" />} 
            trend={`${((stats.totalUsed / (stats.totalIssued || 1)) * 100).toFixed(1)}% de conversão`}
          />
          <StatCard 
            label="Base Importada" 
            value={whitelist.length} 
            icon={<Users className="text-amber-600" />} 
            trend="Assinantes autorizados"
          />
        </div>

        {/* Links Rápidos */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center">
                <LayoutGrid className="text-indigo-600" size={24} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Link da Vitrine (Cliente)</p>
                <p className="text-xs font-bold text-slate-600 truncate max-w-[200px]">{vitrineUrl}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => copyToClipboard(vitrineUrl)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-400 hover:text-indigo-600" title="Copiar Link">
                <Copy size={18} />
              </button>
              <a href={vitrineUrl} target="_blank" rel="noreferrer" className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-400 hover:text-indigo-600" title="Abrir Vitrine">
                <ExternalLink size={18} />
              </a>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center">
                <Store className="text-emerald-600" size={24} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Link do PDV (Operação)</p>
                <p className="text-xs font-bold text-slate-600 truncate max-w-[200px]">{pdvUrl}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => copyToClipboard(pdvUrl)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-400 hover:text-emerald-600" title="Copiar Link">
                <Copy size={18} />
              </button>
              <a href={pdvUrl} target="_blank" rel="noreferrer" className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-400 hover:text-emerald-600" title="Abrir PDV">
                <ExternalLink size={18} />
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Gráfico de Uso */}
          <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <TrendingUp className="text-indigo-600" size={20} /> Performance de Uso
              </h3>
              <button 
                onClick={exportReport}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
              >
                <Download size={14} /> Exportar CSV
              </button>
            </div>
            
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 600}} 
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 600}} 
                  />
                  <Tooltip 
                    cursor={{fill: '#f8fafc'}} 
                    contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}} 
                  />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} barSize={40}>
                    {stats.chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Progress Bars for Limits */}
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 pt-8 border-t border-slate-50">
              {filteredCampaigns.map(c => {
                const now = new Date();
                const currentMonthStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}`;
                const monthData = c.months.find(m => m.month === currentMonthStr);
                const issueLimit = c.monthlyLimit || 100;
                const usageLimit = c.monthlyUsageLimit || issueLimit;
                
                const issuePerc = Math.min(100, ((monthData?.issued_count || 0) / issueLimit) * 100);
                const usagePerc = Math.min(100, ((monthData?.used_count || 0) / usageLimit) * 100);

                return (
                  <div key={c.id} className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-400">
                        <span>Cota de Emissão ({c.name})</span>
                        <span className="text-slate-900">{monthData?.issued_count || 0} / {issueLimit}</span>
                      </div>
                      <div className="h-2 bg-slate-50 rounded-full overflow-hidden">
                        <div className="h-full bg-indigo-500 transition-all duration-1000" style={{ width: `${issuePerc}%` }} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-400">
                        <span>Cota de Utilização</span>
                        <span className="text-slate-900">{monthData?.used_count || 0} / {usageLimit}</span>
                      </div>
                      <div className="h-2 bg-slate-50 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 transition-all duration-1000" style={{ width: `${usagePerc}%` }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Upload de Whitelist */}
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col">
            <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
              <FileSpreadsheet className="text-indigo-600" size={20} /> Gestão de Base
            </h3>
            
            <div className="flex-1 flex flex-col justify-center">
              <p className="text-sm text-slate-500 mb-6 leading-relaxed">
                Suba a lista de códigos de assinantes autorizados para resgatar os vouchers da campanha selecionada.
              </p>
              
              <label className={`
                group flex flex-col items-center justify-center w-full h-48 bg-slate-50 rounded-3xl border-2 border-dashed transition-all text-center p-6
                ${selectedCampaignId === 'all' ? 'opacity-50 cursor-not-allowed border-slate-200' : 'cursor-pointer border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30'}
              `}>
                <UploadCloud className={`w-10 h-10 mb-3 ${selectedCampaignId === 'all' ? 'text-slate-300' : 'text-slate-400 group-hover:text-indigo-500'}`} />
                <p className="text-xs font-black text-slate-500 uppercase tracking-widest mb-1">Upload Planilha</p>
                <p className="text-[10px] text-slate-400 font-medium">Arraste ou clique para selecionar .XLSX</p>
                <input 
                  type="file" 
                  className="hidden" 
                  accept=".xlsx, .xls" 
                  onChange={handleFileUpload} 
                  disabled={selectedCampaignId === 'all'}
                />
              </label>
              
              {selectedCampaignId === 'all' && (
                <p className="mt-4 text-[10px] text-amber-600 font-bold flex items-center gap-1 justify-center">
                  <AlertCircle size={12} /> Selecione uma campanha acima para habilitar o upload.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Lista de Vouchers */}
        <div className="mt-8 bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-8 border-bottom border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h3 className="text-lg font-black text-slate-900">Histórico de Emissões</h3>
            <div className="relative w-full md:w-72">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                placeholder="Buscar por nome, assinante ou código..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-slate-50 rounded-2xl border-none ring-1 ring-slate-200 outline-none text-sm font-medium focus:ring-2 focus:ring-indigo-500 transition-all"
              />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-y border-slate-100">
                  <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Código</th>
                  <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Cliente</th>
                  <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Assinante</th>
                  <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                  <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Data Emissão</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredVouchers.length > 0 ? (
                  filteredVouchers.slice(0, 50).map(v => (
                    <tr key={v.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-4 font-mono text-sm font-bold text-indigo-600">{v.code}</td>
                      <td className="px-8 py-4 font-bold text-slate-700">{v.name}</td>
                      <td className="px-8 py-4 text-sm text-slate-500 font-medium">{v.customerCode}</td>
                      <td className="px-8 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                          v.status === VoucherStatus.USED 
                            ? 'bg-emerald-100 text-emerald-700' 
                            : 'bg-amber-100 text-amber-700'
                        }`}>
                          {v.status === VoucherStatus.USED ? 'Utilizado' : 'Pendente'}
                        </span>
                      </td>
                      <td className="px-8 py-4 text-sm text-slate-400 font-medium">
                        {new Date(v.issuedAt).toLocaleDateString('pt-BR')}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-8 py-12 text-center text-slate-400 font-medium">
                      Nenhum voucher encontrado para os filtros aplicados.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string, value: number, icon: React.ReactNode, trend: string }> = ({ label, value, icon, trend }) => (
  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-5">
    <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center shrink-0">
      {React.cloneElement(icon as React.ReactElement, { size: 28 })}
    </div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-2xl font-black text-slate-900 leading-none mb-2">{value}</p>
      <p className="text-[10px] font-bold text-slate-400">{trend}</p>
    </div>
  </div>
);

export default ContractorDashboard;
